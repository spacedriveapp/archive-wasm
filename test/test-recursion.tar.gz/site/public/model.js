let _model= {
	satisfaction: 5,
	language: 'javascript'
}

export { _model };